#!/usr/bin/env python
# coding: utf-8

# ___
# 
# <a href='https://mainacademy.ua/'> <img src='https://mainacademy.ua/wp-content/uploads/2019/03/logo-main.png' alt = 'Хмм, щось з інтернетом'/></a>
# ___
# 
# # Module 5: Data analysis with NumPy and Pandas

# ## Lab work 5.1
# 
# 

# #### Мета: 
# 
# * навчитися працювати із бібліотекою NumPy в Python

# ### Завдання:

# In[5]:


get_ipython().system('pip install numpy')


# In[3]:


import numpy as np


# Вивести версію та конфігурацію бібліотеки:

# In[3]:


print(np.__version__)
np.show_config()


# Створити вектор з 10 елементів, заповнений одиницями:

# In[8]:


Z = np.ones(10)
Z


# Створити вектор із значеннями від 0 до 10:

# In[15]:


Z = np.array(range(11))
Z


# Створити матрицю 5 на 5, заповнену нулями:

# In[17]:


Z = np.zeros((5, 5))
Z


# Заповнити вектор з 20 елементів випадковими цілими числами. Знайти індекси ненульових елементів:

# In[57]:


import numpy 
numpy.random.seed(42)

Z = numpy.random.randint(0, 20, 20)
print(list(Z))
print(np.nonzero(Z))


# Для вектора із попередньої задачі знайти середнє значення, медіану, стандартне відхилення:

# In[58]:


avg = Z.mean()
print('середнє значення:', avg)

mediana = np.median(Z)
print('медіана:', mediana)

sigma = np.std(Z)
print('стандартне відхилення:', mediana)


# Створити дві матриці випадкових чисел розміром 4х2 та 2х2. Перемножити їх:

# In[6]:


import numpy 
numpy.random.seed(42)

Z = numpy.random.randint(0, 20, (4, 2))
print('матриця 1: \n ',Z)

X = numpy.random.randint(0, 20, (2, 2))
print('матриця 2: \n ',X)

N = Z @ X
print('добуток матриць: \n', N)


# Результуючу матрицю із попередньої задачі перетворити у вектор. Знайти мінімальне та максимальне значення. 
# 
# Максимальне значення замінити на 0:

# In[104]:


K = N.flatten()
print('вектор: ', K)

mi = np.min(K)
print('мінімальне значення: ', mi)
ma = np.max(K)
print('максимальне значення: ', ma)

L = np.where(K != ma, K, 0)
print('Максимальне значення замінити на 0:', L)


# Знайдіть кореляцію першого рядка матриці із попереднього завдання із іншими рядками:

# In[9]:


cor_0_1 = np.corrcoef(N[0], N[1])
cor_0_2 = np.corrcoef(N[0], N[2])
cor_0_3 = np.corrcoef(N[0], N[3])

print('кореляція першого рядка матриці N до її другого рядка: ', cor_0_1)
print('кореляція першого рядка матриці N до її третього рядка: ', cor_0_2)
print('кореляція першого рядка матриці N до її четвертого рядка: ', cor_0_3)


# Дано матрицю. Знайти ранг матриці:

# In[106]:


a = np.array([[ 1,  4, 5],
              [7, 3, 2],
              [9, 16, 1]])


# Знайти визначник матриці:

# In[116]:


rank = np.linalg.matrix_rank(a)
print(rank)


# Знайти власні значення та власні вектори матриці: 

# In[122]:


from numpy import linalg as LA

w, v = LA.eig(np.array(a))
print(w, v)


# Знайдіть число, що найчастіше зустрічається в масиві:

# In[140]:


from collections import Counter

a = np.random.randint(0,10,50)
print('масив: \n',a)

b = Counter(a)
print('підрахунок чисел в масиві: ' , b)
print('число, що найчастіше зустрічається в масиві:', b.most_common(1)[0][0])


# Виведіть лише парні числа, що діляться на 5:

# In[146]:


a = np.random.randint(0,10,50)
b = a[a % 2 == 0]
c = b[b % 5 == 0]
print('парні числа: ' , b)
print('парні числа, які діляться на 5: ' ,c)


# Розв'яжіть систему рівнянь:
# $$2x + 5y = 1 $$
# 
# $$x - 10y = 3  $$
#    

# In[150]:


matrix = numpy.array([[2, 5], [1, -10]]) 
vector = numpy.array([1, 3]) 

result = numpy.linalg.solve(matrix, vector)
print('x = ', result[0])
print('y = ', result[1])

